use tokio::{sync::{mpsc, watch}, time::interval};
use crate::veri_tipleri::{AracMod, GelenTelemetri, GidenTelemetri, GpsVeri, ImuVeri, MotorEsleme, MotorVeri};
use std::{f64::consts::PI, time::{Duration, Instant}};

pub struct PidKontrolcu
{
    pub kp: f64,
    pub ki: f64,
    pub kd: f64,
    integral: f64,
    onceki_hata: f64,
    integral_siniri: f64,
}

impl PidKontrolcu
{
    pub fn new(kp: f64, ki: f64, kd: f64, integral_siniri: f64) -> Self
    {
        Self
        {
            kp,
            ki,
            kd,
            integral: 0.0,
            onceki_hata: 0.0,
            integral_siniri,
        }
    }

    pub fn guncelle(&mut self, hata: f64, dt: f64) -> f64
    {
        self.integral += hata * dt;
        self.integral = self.integral.clamp(-self.integral_siniri, self.integral_siniri);
        let turev = if dt > 0.0 { ((hata - self.onceki_hata) / dt).clamp(-100.0, 100.0) } else { 0.0 };
        self.onceki_hata = hata;
        (self.kp * hata) + (self.ki * self.integral) + (self.kd * turev)
    }
}

const IHMALACI: f64 = 3.0;
const HEDEF_TOLERANS: f64 = 2.5;
const MANUEL_OLU_BOLGE: f32 = 0.02;
const MIN_GPS_FIX: u8 = 3;
const MIN_GPS_UYDU: u8 = 6;

// Varsayılan fiziksel motor sırası:
// Varsayılan: M1 = sağa yatay, M2 = sola yatay, M3 = ileri-2, M4 = ileri-1
// Bu sıra artık YKİ'den CMD:MAP:sol,ileri1,sag,ileri2 komutuyla değiştirilebilir.
//
// Manuel paket: CMD:MAN:ileri,yatay
// ileri: 0.0..1.0
// yatay: -1.0..1.0  (eksi=sol, artı=sağ)
fn motor_kanalina_yaz(motor: &mut MotorVeri, kanal: u8, deger: u16)
{
    match kanal
    {
        1 => motor.iskeleon = deger,
        2 => motor.iskelearka = deger,
        3 => motor.sancakon = deger,
        4 => motor.sancakarka = deger,
        _ => {}
    }
}

fn gps_gecerli(gps: &GpsVeri) -> bool
{
    gps.algi_boyut >= MIN_GPS_FIX
        && gps.uydu_sayi >= MIN_GPS_UYDU
        && gps.enlem != 0
        && gps.boylam != 0
}

fn koordinat_gecerli(lat: f64, lon: f64) -> bool
{
    lat.is_finite()
        && lon.is_finite()
        && (-90.0..=90.0).contains(&lat)
        && (-180.0..=180.0).contains(&lon)
        && !(lat == 0.0 && lon == 0.0)
}

fn manuel_motor_karistir(
    ileri_girdisi: f32,
    yatay_girdisi: f32,
    esleme: MotorEsleme,
) -> MotorVeri
{
    let ileri = ileri_girdisi.clamp(0.0, 1.0);
    let yatay = yatay_girdisi.clamp(-1.0, 1.0);
    let mut motor = MotorVeri::default();

    if !esleme.gecerli()
    {
        return motor;
    }

    // Gaz/ileri ve yatay komutu ölü bölgede ise açı ne olursa olsun bütün kanallar sıfırdır.
    if ileri <= MANUEL_OLU_BOLGE && yatay.abs() <= MANUEL_OLU_BOLGE
    {
        return motor;
    }

    let ileri_komutu = if ileri > MANUEL_OLU_BOLGE
    {
        (ileri * 1000.0).round() as u16
    }
    else
    {
        0
    };

    let yatay_komutu = if yatay.abs() > MANUEL_OLU_BOLGE
    {
        (yatay.abs() * 1000.0).round() as u16
    }
    else
    {
        0
    };

    // İki ileri motor kesinlikle aynı değişkenden beslenir.
    motor_kanalina_yaz(&mut motor, esleme.ileri1, ileri_komutu);
    motor_kanalina_yaz(&mut motor, esleme.ileri2, ileri_komutu);

    if yatay < -MANUEL_OLU_BOLGE
    {
        motor_kanalina_yaz(&mut motor, esleme.sol, yatay_komutu);
    }
    else if yatay > MANUEL_OLU_BOLGE
    {
        motor_kanalina_yaz(&mut motor, esleme.sag, yatay_komutu);
    }

    motor
}

pub struct NavData
{
    origin_enlem: f64,
    origin_boylam: f64,
    cos_enlem: f64,
    is_origin_set: bool,
    gps_ornek_sayaci: u8,
    ornek_enlem_toplam: i64,
    ornek_boylam_toplam: i64,
    son_ornek_enlem: i32,
    son_ornek_boylam: i32,
    current_x: f64,
    current_y: f64,
    current_yaw: f64,
    hedef_noktalar: Vec<(f64, f64)>,
    current_hn_index: usize,
}

impl NavData
{
    pub fn new() -> Self
    {
        Self
        {
            origin_enlem: 0.0,
            origin_boylam: 0.0,
            cos_enlem: 1.0,
            is_origin_set: false,
            gps_ornek_sayaci: 0,
            ornek_enlem_toplam: 0,
            ornek_boylam_toplam: 0,
            son_ornek_enlem: 0,
            son_ornek_boylam: 0,
            current_x: 0.0,
            current_y: 0.0,
            current_yaw: 0.0,
            hedef_noktalar: Vec::new(),
            current_hn_index: 0,
        }
    }

    pub fn guvenli_origin_belirle(&mut self, gps: &GpsVeri) -> bool
    {
        let yeterli_fix = gps.algi_boyut >= 3; 
        let yeterli_uydu = gps.uydu_sayi >= 6;
        let gecerli_koordinat = gps.enlem != 0 && gps.boylam != 0;
        if !yeterli_fix || !yeterli_uydu || !gecerli_koordinat
        {
            self.gps_ornek_sayaci = 0;
            self.ornek_enlem_toplam = 0;
            self.ornek_boylam_toplam = 0;
            return false;
        }
        if gps.enlem == self.son_ornek_enlem && gps.boylam == self.son_ornek_boylam
        {
            return false;
        }
        self.son_ornek_enlem = gps.enlem;
        self.son_ornek_boylam = gps.boylam;
        self.ornek_enlem_toplam += gps.enlem as i64;
        self.ornek_boylam_toplam += gps.boylam as i64;
        self.gps_ornek_sayaci += 1;
        if self.gps_ornek_sayaci >= 10
        {
            let ortalama_enlem = (self.ornek_enlem_toplam / 10) as i32;
            let ortalama_boylam = (self.ornek_boylam_toplam / 10) as i32;
            self.origin_enlem = ortalama_enlem as f64 / 10_000_000.0;
            self.origin_boylam = ortalama_boylam as f64 / 10_000_000.0;
            self.cos_enlem = (self.origin_enlem * std::f64::consts::PI / 180.0).cos();
            self.is_origin_set = true;
            self.son_ornek_boylam = 0;
            self.son_ornek_enlem = 0;
            self.ornek_enlem_toplam = 0;
            self.ornek_boylam_toplam= 0;
            return true;
        }
        false
    }

    pub fn guncelle_konum(&mut self, lat_i32: i32, lon_i32: i32, yaw: f64)
    {
        let lat = lat_i32 as f64 / 10_000_000.0;
        let lon = lon_i32 as f64 / 10_000_000.0;
        self.current_y = (lat - self.origin_enlem) * 111_320.0;
        self.current_x = (lon - self.origin_boylam) * 111_320.0 * self.cos_enlem;
        self.current_yaw = yaw;
    }

    pub fn set_rota(&mut self, noktalar: Vec<(f64, f64)>)
    {
        self.hedef_noktalar = noktalar;
        self.current_hn_index = 0;
    }

    pub fn guncel_hedef(&self) -> Option<(f64, f64)>
    {
        if self.current_hn_index < self.hedef_noktalar.len()
        {
            Some(self.hedef_noktalar[self.current_hn_index])
        }
        else
        {
            None
        }
    }
    pub fn calc_mesafe(&self, hedef_x: f64, hedef_y: f64) -> f64
    {
        let dx = hedef_x - self.current_x;
        let dy = hedef_y - self.current_y;
        (dx * dx + dy * dy).sqrt()
    }

    pub fn calc_hedefeaci(&self, hedef_x: f64, hedef_y: f64) -> f64
    {
        let dx = hedef_x - self.current_x;
        let dy = hedef_y - self.current_y;
        dx.atan2(dy) * 180.0 / PI
    }

    pub fn bakisyonu_hata(&self, hedefeaci: f64) -> f64
    {
        let mut hata = hedefeaci - self.current_yaw;
        while hata > 180.0 { hata -= 360.0 }
        while hata < -180.0 { hata += 360.0 }
        hata
    }
}

pub async fn nav_task(
    imu_rx: watch::Receiver<ImuVeri>,
    gps_rx: watch::Receiver<GpsVeri>,
    motor_tx: mpsc::Sender<MotorVeri>,
    mut rx_yki: mpsc::Receiver<GelenTelemetri>,
    yki_tx: mpsc::Sender<GidenTelemetri>,
)
{
    let mut tick = interval(Duration::from_millis(50));
    let mut last_time = Instant::now();
    let mut nav = NavData::new();
    let mut pid = PidKontrolcu::new(4.0, 0.1, 0.5, 150.0);
    let base_hiz: f32 = 400.0;
    let mut kaba_donus_modu = false;
    let mut guncel_mod = AracMod::Manuel;
    let mut telemetri_sayaci = 0;
    let mut son_manuel_ileri: f32 = 0.0;
    let mut son_manuel_yatay: f32 = 0.0;
    let mut manuel_komut_alindi = false;
    let mut motor_esleme = MotorEsleme::default();
    // Öncelik YKİ'den gelen CMD:HOME koordinatıdır. Gönderilmezse ilk güvenilir
    // GPS origin'i otomatik olarak kalkış/geri dönüş noktası kabul edilir.
    let mut eve_donus_noktasi: Option<(f64, f64)> = None;
    let mut telemetri_bagli = false;
    let mut eve_donus_tamamlandi = false;
    println!(
        "Motor eşlemesi başlangıç: sol=M{}, ileri=M{}+M{}, sağ=M{}",
        motor_esleme.sol,
        motor_esleme.ileri1,
        motor_esleme.ileri2,
        motor_esleme.sag,
    );
    loop
    {
        tick.tick().await;
        let simdi = Instant::now();
        let dt = simdi.duration_since(last_time).as_secs_f64();
        last_time = simdi;

        while let Ok(komut) = rx_yki.try_recv()
        {
            match komut
            {
                GelenTelemetri::AcilDurdur =>
                {
                    guncel_mod = AracMod::AcilDurum;
                    son_manuel_ileri = 0.0;
                    son_manuel_yatay = 0.0;
                    manuel_komut_alindi = false;
                    println!("Acil durdur!");
                }
                GelenTelemetri::GoreviBaslat =>
                {
                    if guncel_mod != AracMod::AcilDurum
                    {
                        if !nav.hedef_noktalar.is_empty()
                        {
                            son_manuel_ileri = 0.0;
                            son_manuel_yatay = 0.0;
                            manuel_komut_alindi = false;
                            guncel_mod = AracMod::Otonom;
                            println!("Otonom Modu");
                        }
                        else
                        {
                            println!("Rotasız otonom moduna geçilmez.");
                        }
                    }
                }
                GelenTelemetri::ModDegistir(istenen_mod) =>
                {
                    guncel_mod = istenen_mod;
                    son_manuel_ileri = 0.0;
                    son_manuel_yatay = 0.0;
                    manuel_komut_alindi = false;
                    println!("Mod değişimi: {:?}", guncel_mod);
                }
                GelenTelemetri::ManuelKontrol(ileri, yatay) =>
                {
                    guncel_mod = AracMod::Manuel;
                    son_manuel_ileri = ileri.clamp(0.0, 1.0);
                    son_manuel_yatay = yatay.clamp(-1.0, 1.0);
                    manuel_komut_alindi = true;
                    println!(
                        "Manuel PWM sabitlendi: ileri={:.3}, yatay={:.3}; DUR/STOP gelene kadar korunacak.",
                        son_manuel_ileri,
                        son_manuel_yatay,
                    );
                }
                GelenTelemetri::MotorEslemeDegistir(yeni_esleme) =>
                {
                    if yeni_esleme.gecerli()
                    {
                        motor_esleme = yeni_esleme;
                        son_manuel_ileri = 0.0;
                        son_manuel_yatay = 0.0;
                        manuel_komut_alindi = false;
                        println!(
                            "Motor eşlemesi güncellendi: sol=M{}, ileri=M{}+M{}, sağ=M{}",
                            motor_esleme.sol,
                            motor_esleme.ileri1,
                            motor_esleme.ileri2,
                            motor_esleme.sag,
                        );
                    }
                }
                GelenTelemetri::EvKonumuBelirle(lat, lon) =>
                {
                    if koordinat_gecerli(lat, lon)
                    {
                        eve_donus_noktasi = Some((lat, lon));
                        eve_donus_tamamlandi = false;
                        println!("Güvenli dönüş konumu YKİ'den alındı: {:.7}, {:.7}", lat, lon);
                    }
                }
                GelenTelemetri::TelemetriBaglandi =>
                {
                    if !telemetri_bagli
                    {
                        println!("Telemetri yeniden bağlandı.");
                    }
                    telemetri_bagli = true;
                    // Güvenli dönüş başladıysa bağlantı geri gelse bile hedefe kadar
                    // devam eder. YKİ yeni bir mod/STOP komutuyla bunu değiştirebilir.
                }
                GelenTelemetri::TelemetriKoptu =>
                {
                    if telemetri_bagli
                    {
                        eprintln!("Telemetri koptu: güvenli dönüş hazırlanıyor.");
                    }
                    telemetri_bagli = false;
                    eve_donus_tamamlandi = false;
                    son_manuel_ileri = 0.0;
                    son_manuel_yatay = 0.0;
                    manuel_komut_alindi = false;

                    if guncel_mod != AracMod::AcilDurum
                    {
                        let gps_anlik = *gps_rx.borrow();
                        if eve_donus_noktasi.is_some() && gps_gecerli(&gps_anlik)
                        {
                            guncel_mod = AracMod::EveDonus;
                            pid.integral = 0.0;
                            kaba_donus_modu = false;
                            println!("EVE DÖNÜŞ MODU: motor kontrolü güvenli dönüş konumuna yönlendirildi.");
                        }
                        else
                        {
                            // Hedef veya güvenilir GPS yoksa rastgele hareket edilmez.
                            guncel_mod = AracMod::GorevBekliyor;
                            eprintln!("Eve dönüş başlatılamadı: güvenli HOME veya geçerli GPS yok. Motorlar duruyor.");
                        }
                    }
                }
                GelenTelemetri::TelemetriHeartbeat =>
                {
                    // Bağlantı watchdog'u telemetri katmanında tutulur.
                }
                GelenTelemetri::RotaBelirle(noktalar) =>
                {
                    nav.set_rota(noktalar);
                    son_manuel_ileri = 0.0;
                    son_manuel_yatay = 0.0;
                    manuel_komut_alindi = false;
                    guncel_mod = AracMod::GorevBekliyor;
                    println!("Yeni rota: ({} nokta)", nav.hedef_noktalar.len());
                }
            }
        }
        let gps = gps_rx.borrow().clone();
        let imu = imu_rx.borrow().clone();
        let mut motor_istek = MotorVeri::default();
        let mut anlik_hedef_aci = imu.yaw as f64;
        if guncel_mod == AracMod::Manuel && manuel_komut_alindi
        {
            // Son manuel komut kilitlenir. Yeni CMD:MAN, DUR/0 komutu, STOP veya
            // mod değişimi gelene kadar aynı PWM her 50 ms motor katmanına gönderilir.
            motor_istek = manuel_motor_karistir(
                son_manuel_ileri,
                son_manuel_yatay,
                motor_esleme,
            );
        }
        if !nav.is_origin_set
        {
            if nav.guvenli_origin_belirle(&gps) && eve_donus_noktasi.is_none()
            {
                eve_donus_noktasi = Some((nav.origin_enlem, nav.origin_boylam));
                eve_donus_tamamlandi = false;
                println!(
                    "Otomatik güvenli dönüş konumu (ilk GPS origin): {:.7}, {:.7}",
                    nav.origin_enlem,
                    nav.origin_boylam,
                );
            }
        }
        else
        {
            // Kopma anında GPS geçersizse motorlar durur. GPS tekrar güvenilir
            // olduğunda aynı kopma için güvenli dönüş otomatik başlatılır.
            if !telemetri_bagli
                && !eve_donus_tamamlandi
                && guncel_mod != AracMod::AcilDurum
                && guncel_mod != AracMod::EveDonus
                && eve_donus_noktasi.is_some()
                && gps_gecerli(&gps)
            {
                guncel_mod = AracMod::EveDonus;
                son_manuel_ileri = 0.0;
                son_manuel_yatay = 0.0;
                manuel_komut_alindi = false;
                pid.integral = 0.0;
                kaba_donus_modu = false;
                println!("GPS hazır: telemetri kopuk güvenli dönüşü başlatıldı.");
            }

            nav.guncelle_konum(gps.enlem, gps.boylam, imu.yaw as f64);
            anlik_hedef_aci = imu.yaw as f64;
            if matches!(guncel_mod, AracMod::Otonom | AracMod::EveDonus)
            {
                let hedef = if guncel_mod == AracMod::EveDonus
                {
                    eve_donus_noktasi
                }
                else
                {
                    nav.guncel_hedef()
                };

                if let Some((hedef_lat, hedef_lon)) = hedef
                {
                    let hedefy_metre = (hedef_lat - nav.origin_enlem) * 111_320.0;
                    let hedefx_metre = (hedef_lon - nav.origin_boylam) * 111_320.0 * nav.cos_enlem;
                    let mesafe = nav.calc_mesafe(hedefx_metre, hedefy_metre);
                    let hedefe_aci = nav.calc_hedefeaci(hedefx_metre, hedefy_metre);
                    let hata = nav.bakisyonu_hata(hedefe_aci);
                    anlik_hedef_aci = hedefe_aci;
                    if mesafe < HEDEF_TOLERANS
                    {
                        if guncel_mod == AracMod::EveDonus
                        {
                            println!("Güvenli dönüş konumuna ulaşıldı. Motorlar durduruldu.");
                            eve_donus_tamamlandi = true;
                            guncel_mod = AracMod::GorevBekliyor;
                        }
                        else
                        {
                            println!("{}. hedef noktasına ulaşıldı!", nav.current_hn_index + 1);
                            nav.current_hn_index += 1;
                        }
                        pid.integral = 0.0;
                        pid.onceki_hata = hata;
                        kaba_donus_modu = false;
                    }
                    else
                    {
                        let onceki_kaba = kaba_donus_modu;
                        if hata.abs() > 30.0
                        {
                            kaba_donus_modu = true;
                        } else if hata.abs() < 15.0
                        {
                            kaba_donus_modu = false;
                        }
                        if onceki_kaba && !kaba_donus_modu
                        {
                            pid.integral = 0.0;
                            pid.onceki_hata = hata;
                        }
                        let donus_gucu = if kaba_donus_modu { 0.0 } else { pid.guncelle(hata, dt) };
                        if kaba_donus_modu
                        {
                            if hata < 0.0
                            {
                                motor_kanalina_yaz(&mut motor_istek, motor_esleme.sag, 400);
                            }
                            else
                            {
                                motor_kanalina_yaz(&mut motor_istek, motor_esleme.sol, 400);
                            }
                        }
                        else
                        {
                            let duzeltme = if hata.abs() < IHMALACI { 0.0 } else { donus_gucu };

                            // YKİ'den seçilmiş iki ileri motor daima aynı komutu alır.
                            let ileri_komutu = base_hiz.clamp(0.0, 1000.0) as u16;
                            motor_kanalina_yaz(&mut motor_istek, motor_esleme.ileri1, ileri_komutu);
                            motor_kanalina_yaz(&mut motor_istek, motor_esleme.ileri2, ileri_komutu);

                            // Yön düzeltmesi seçilmiş yatay motorlarla yapılır.
                            if duzeltme > 0.0
                            {
                                motor_kanalina_yaz(
                                    &mut motor_istek,
                                    motor_esleme.sol,
                                    duzeltme.clamp(0.0, 1000.0) as u16,
                                );
                            }
                            else if duzeltme < 0.0
                            {
                                motor_kanalina_yaz(
                                    &mut motor_istek,
                                    motor_esleme.sag,
                                    (-duzeltme).clamp(0.0, 1000.0) as u16,
                                );
                            }
                        }
                    }
                }
                else
                {
                    guncel_mod = AracMod::GorevBekliyor;
                    if !telemetri_bagli
                    {
                        eprintln!("Telemetri yok ve güvenli dönüş hedefi bulunamadı. Motorlar duruyor.");
                    }
                }
            }
        }

        let _ = motor_tx.send(motor_istek.clone()).await;

        telemetri_sayaci += 1;
        if telemetri_sayaci % 2 == 0
        {
            let telemetri_paketi = GidenTelemetri
            {
                arac_enlem: gps.enlem as f64 / 10_000_000.0,
                arac_boylam: gps.boylam as f64 / 10_000_000.0,
                yer_hiz: gps.hiz as f32,
                setpoint_hiz: match guncel_mod
                {
                    AracMod::Otonom | AracMod::EveDonus => 2.0,
                    AracMod::Manuel => son_manuel_ileri.clamp(0.0, 1.0) * 2.0,
                    _ => 0.0,
                },
                imu_veri: (imu.roll, imu.pitch, imu.yaw),
                setpoint_yaw: anlik_hedef_aci as f32,
                arac_mod: guncel_mod,
                motorlar_veri: (motor_istek.iskeleon, motor_istek.iskelearka, motor_istek.sancakon, motor_istek.sancakarka),
                motorlar_istek: (motor_istek.iskeleon, motor_istek.iskelearka, motor_istek.sancakon, motor_istek.sancakarka),
            };
            // Telemetri kopukken bu kanalın dolması navigasyon döngüsünü kesinlikle
            // durdurmamalı. Paket sığmıyorsa eski telemetri atılır, dönüş sürer.
            let _ = yki_tx.try_send(telemetri_paketi);
        }
    }
}
